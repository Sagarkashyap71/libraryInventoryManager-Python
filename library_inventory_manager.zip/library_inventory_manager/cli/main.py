
import logging
from library_manager.book import Book
from library_manager.inventory import LibraryInventory

logging.basicConfig(filename="library.log", level=logging.INFO)

def menu():
    print("\n1. Add Book")
    print("2. Issue Book")
    print("3. Return Book")
    print("4. View All Books")
    print("5. Search Book")
    print("6. Exit")
    return input("Enter choice: ")

def main():
    inv = LibraryInventory()
    while True:
        c = menu()
        if c == "1":
            t=input("Title: "); a=input("Author: "); i=input("ISBN: ")
            inv.add_book(Book(t,a,i)); inv.save_books()
        elif c=="2":
            i=input("ISBN: "); b=inv.search_by_isbn(i)
            if b and b.issue(): inv.save_books()
        elif c=="3":
            i=input("ISBN: "); b=inv.search_by_isbn(i)
            if b and b.return_book(): inv.save_books()
        elif c=="4":
            inv.display_all()
        elif c=="5":
            q=input("Search: "); b=inv.search_by_isbn(q)
            if b: print(b)
            else:
                r=inv.search_by_title(q)
                for x in r: print(x)
        elif c=="6":
            break

if __name__=="__main__":
    main()
