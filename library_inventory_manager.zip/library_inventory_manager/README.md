# Library Inventory Manager
Python OOP project.